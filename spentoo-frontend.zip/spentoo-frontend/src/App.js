import React from "react";
import Login from "./pages/Auth/Login"; // Import your Login page

function App() {
  return <Login />; // Render only the Login page
}

export default App;
