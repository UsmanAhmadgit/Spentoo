import React from "react";
import Login from "./pages/Auth/Login";

function App() {
  return <Login />; // Renders only the Login page
}

export default App;
